/Users/wesley/important/spark-2.4.0-bin-hadoop2.7/bin/spark-submit --master local[2] --name spark-local /Users/wesley/codes/bigdatafinal/data_process/main_data_processor.py
