/Users/wesley/important/spark-2.4.0-bin-hadoop2.7/bin/spark-submit --master local[2] --name spark-local2 /Users/wesley/codes/bigdatafinal/data_process/predict_model.py
